// Simple interactions for the landing page
document.addEventListener('DOMContentLoaded', () => {
  // 1) Gallery: thumbnails -> main image
  const main = document.getElementById('gallery-main');
  const thumbs = Array.from(document.querySelectorAll('.thumb'));
  if (main && thumbs.length) {
    // Ensure initial state
    main.src = thumbs[0].dataset.full || thumbs[0].src;
    thumbs.forEach(t => {
      t.addEventListener('click', () => {
        const full = t.dataset.full || t.src;
        main.src = full;
        thumbs.forEach(x => x.classList.remove('active'));
        t.classList.add('active');
      });
    });
  }

  // 2) Scroll Effect: toggle .scrolled on header
  const header = document.querySelector('.site-header');
  const onScroll = () => {
    if (window.scrollY > 20) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // 3) Reveal animation for feature items with Intersection Observer
  const items = document.querySelectorAll('.feature-item');
  if ('IntersectionObserver' in window && items.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const delay = Number(entry.target.dataset.delay || 0);
          setTimeout(() => entry.target.classList.add('in-view'), delay);
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.15 });
    items.forEach(el => io.observe(el));
  } else {
    // Fallback: show immediately
    items.forEach(el => el.classList.add('in-view'));
  }

  // Optional: close mobile nav after clicking a link (CSS-only menu uses checkbox)
  const navToggle = document.getElementById('nav-toggle');
  document.querySelectorAll('.main-nav a').forEach(a => {
    a.addEventListener('click', () => {
      if (navToggle && navToggle.checked) navToggle.checked = false;
    });
  });
});
